

## Page 2

Ø  
Ø  
Ø  
Ø  
Ø  
Ø  
Ø  
Ø  
Ø  
Ø  
Ø   
Ø  
Ø  
Ø  
Ø  
Ø  
Ø  
Ø  
Ø  
 
 
  
 MARKETING  STRATEGIES


## Page 3

COMPANY INFORMATION


## Page 4

Limited is an indigenous based international company own 
and managed by Polish Nigerian.  We engage in all kind of civil engineering 
services, design, construction,  agriculture, import and export of construction 
materials and other goods, maintenance upplies 
and procurements, bid contracts, turnkey contracting and management 
contracting, developing estates and properties management. 
The ability of  Limited  to provide quality service is 
accounted for by the commitment of the management team to customer 
satisfaction. 
The team consists of dynamic and self motivated young men with proactive 
tendencies. The company management team has executed so many 
uction 
within the last forty three years (43yrs) in Polish, Jamaica, Romania and  
Nigeria.  
NATURE OF BUSINESS


## Page 7

Facilities Management services and has acquired extensive experience in quite a 
number of states in the federation. Services provided are in the areas stated 
below: 
Ø . 
Ø . 
Ø Dams  
Ø Bridges. 
Ø  
Ø  
Ø   
Ø   
Ø Drilling of borehole. 
Ø . 
Ø   
Ø  
Ø  
Ø Overseas Financing. 
 
work while balancing Cost, Schedule and Quality. 
 
  
 
 
 
 
 
 
 
  
is a company, wholly owned and operated by highly 
in Civil Engineering Design and Implementation, Project Management and A
Nigeria / Polish Professional


## Page 8

CERTIFICATE
OF
INCORPORATION & OTHER
REGISTRATION


## Page 48

Note: Hallekem Limited Turnover Average for the 
last three years (2022,2023,2024) is N12.04B


## Page 49

Note: Hallekem Limited Turnover Average for the 
last three years (2019,2020,2021) is N19.36B


## Page 158

COMPANY CORPORATE  
BANKERS


## Page 159

Ø    
 
Ø   
 
  
 
Ø  
   
 
 
 
 
 
 
 
 
 
 
 
 
 Ø WEMA BANK


## Page 167

  To  
   
  
 
 
 
  the 
 
  
 
  
 
 
 
 
 Limited is an indigenous based international company 
own and managed by Israeli Nigerian.  We engage in all kind of civil 
engineering services, design, construction, agriculture, import and export 
of construction materials and other goods, maintenance 
services, general supplies and procurements, bid contracts, turnkey 
contracting and management contracting, developing estates and 
properties management. 
The ability of   Limited  to provide quality service is 
accounted for by the commitment of the management team to customer 
satisfaction. 
 
 
In order to serve our customers and maintain adequate contact with our  
within Abuja. 
 .


## Page 168

Limited is committed to a better product delivery in 
Telecommunication sector and other services provider. 
To stay ahead of the competition, innovative methods will be used in 
attaining the stated objectives.  
 
 
 
  
 
 
  
 
  
 
 
  
 
  
 
 
 
In line with the overall policy objectives our objectives are: 
  
 
  
 
  To increase our annua


## Page 169

This is base on the following strategies: 
   
We ensure that our clients get the best services required handle clients  
queries, complains and suggestion promptly and favorably 
 
 
 
The company has its own cultural identity, which is amply shown by all 
 
It works on the bases of what motivate people, how they think and learn 
and how they can be changed. 
 The company encourage team work and continuous improvement in it 
he culture also informs the structure, the procedure for 
solving problems. 
 
 
  
  
Ø  
Ø  
Ø Bsc. Mechanical (Transport Engineer) 
Ø  
Ø  
Ø  
Ø Computer Engineer 
Ø Project Manager 
Ø Surveyor 
Ø Geologist 
Ø Logistic / Supply Chain Manager 
Ø Site Quantity Surveyor 
Ø Purchasing Manager 
Ø Contract Manager. 
Ø P.R.O Bsc.


## Page 170

Personal Data:  
      
     MarriedPolish
 
  Business Experience 43 Years  
 
 
Adeyinka Martins Elebute (Financial/Opretional  Manager) 
Personal Data: 
      Nigeria 
     Married 
  Working Experience 16 years  
   
 
Engr. Emmanuel Olagunju  
Personal Data: 
      Nigeria 
     Married 
  Working Experience 7 Years  
   
 and Civil Engineer (COREN P . 1026)
Graduate of B.Sc. Accoun ng and Banking & Finance 
Graduate of Civil Engineer (COREN R. 28,137) Engr. Sunday Jolaya (Chief Engr.)  
Personal Data: 
      Nigeria 
     Married 
  Working Experience 42 Years  
   
  
Orenstain, Vasile (Engr.) PhD 
Personal Data: 
      Romania  
     Married  
  Working Experience 43 years  
   Engr. PhD (P .0677)KEY STAFF:
Engr. Haim Halle (Managing Director/CEO)
Graduate of Msc (Bridge Engr.), B. Engr. Civil Engr.   (COREN R.)


## Page 171

Personal Data:
 
Valentine Oshotse Eleta Ph.D (Environmental Management)
Personal Data: 
      Nigeria 
     Married 
  Working Experience  15 years  
   
 
Adegbola Oluwole Adetunji (Geographic Information System GIS)
Personal Data: 
      Nigeria  
     Married  
  Working Experience 16 years  
   Graduate of PhD Building, Industrial and Civil Engineer KEY STAFF:
Ango Mohammed Fatima (Quantity Surveyor)
 
Engr. Osakwe Petrus Ehigie  
Personal Data: 
      Nigeria 
     Married 
  Working Experience 14 years  
   
  
Personal Data:    
      Nigeria 
     Married 
  Working Experience 14 years  
    
 
 
 
 
 Graduate of Civil Engineer (COREN R. 1704ET) 
Engr. Anazodo Ndu Theodore
Graduate of Civil Engineer  
      Nigeria 
     Married 
  Working Experience 7 years   
   Graduate of B.Sc. Q.S.
Graduate of Ph.D (Environmental Management)


## Page 173

Resume : Engr. Haim Halle


## Page 174

Resume : Engr. Haim Halle


## Page 175

Resume : Engr. Haim Halle


## Page 176

Resume : Engr. Haim Halle


## Page 177

Resume : Engr. Haim Halle


## Page 178

Resume : Engr. Haim Halle


## Page 179

Resume : Engr. Haim Halle


## Page 180

Resume : Engr. Haim Halle


## Page 181

Resume : Engr. Haim Halle


## Page 182

Resume : Engr. Haim Halle


## Page 183

Resume : Engr. Haim Halle


## Page 184

Resume : Engr. Haim Halle


## Page 185

Resume : Engr. Haim Halle


## Page 186

Resume : Engr. Haim Halle


## Page 187

Resume : Engr. Haim Halle


## Page 188

LIST OF EQUIPMENTS


## Page 189

LIST OF EQUIPMENTS 
1. 30 Ton Trucks  
2. Concrete Mixers  
3. Pumping Machines  
4. Jeeps  
5. Compactors  
6. Leveling Instrument  
7. Total Station V30Plus  
8. Dumpers  
9. Welding Machines   
 18. Bulldozers D8
                                     
 10.  Drilling Rigs   
11.  Air Compressors  HALLEKEM
 
Through our hire and lease agreements, additional equipment can be 
made readily available to the company. As such the company is able to 
mobilize the following equipment / machinery:  
12.  Water Jet Machines    
13.  Tug Wrench    
19. Excavators 330    
20. Loaders 966G   
21. Batching plant  
22. Graders 140H  14.  Drilling Machines   
15.  Sheep Leg Compactors  
16.      
17.  Removable Storages     23. Soil and Concrete Lab. Equipments  
24. Steel Compactors  
25. Bomag  20/24R  
26. Paver V ogele
27. 350kva Sound Proof Generator
28. Water Tankers 
29. Jack Hammers 
30. Generators 
31. Cutting Machines 
32. Fully Equipped Removable Oﬃces 
33. Light Tower Generators


## Page 236

The Rehabilitation of Murtala Mohammed Bridge, Koton-Karfe, Kogi State
Hallekem Limited, New Twelve (12) Galvanized, 
“Finger” Type Expansion Joints on site before installation, July 2022


## Page 288

SCOPE OF WORK 
 
 provides 
turnkey solutions for Major Site 
Builder and  Contractors. 
 
achieve 
a market advantage, by providing cost 
competitive construction services, 
quality, safety and schedule attainment.   HALLEKEM LTD  is committed to 
providing a team of professionals dedicated 
to providing high quality project while 
developing and sustaining long term 
working relationship 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 A


## Page 289

PROJECTS 
 
No matter what we do, our core values must always remain the same; to 
deliver quality and excellence, expertly and responsibly. 
Our customers success is vita to our success and we must strive to deliver 
the very best in everything we do.


## Page 290

HALLEKEM LTD  
CORPORATE SAFETY POLICY MANUAL  
 
 
Safety as a major part of investment in the continuity  of life is of particular 
importance in the day-to-  
 
 
In setting up this safety policy, we have set up guidelines, which will direct and 
 
 
 
 
 construction carried out various jobs on contact basis for 
various institutions – private individuals, public  corporations, federal and state 
construction and other heavy engineering works. 
 
It is the uttermost aim of this company that all activities associated with various 
jobs unde rtaken are executed in such a way that the health and safety of its 
workers are safe guarded.  
 
In this regard ,  construction will not only comply with all 
application safety laws but also in addition comply with all safety regulations 
for all institution it works for. 
 
project sites shall have that particular role of ensuring that I work for which they 
are responsible, are properly supervised and work practices employed are safe 
responsibility of every employee since we know that achieving an accident free 
operation  
 
 
basis, weekly site safety meetings shall be held on the various projects sites to 
inculcate in workers, company’s safety regulations.


## Page 291

time the company will provide safety equipment like safety booth, helmets, 
hand gloves, rain coats etc. for use by all employees and visitors on site. 
 
Employees shall from time to time be nominated for specialized courses such as 
– 
swimming etc. at the end of these courses, they should be able to identify and 
eliminate hazards in their various 
safety course shall take precedence over all other companies activities 
 
 
The safety policy of guidelines of  are as follows  
(a)  Promotion of safety consciousness in all workers  
(b)  Only skilled workers shall be engaged in specialized operations  
(c)  All workers shall be educated on the safety, rules of our various clients.  
(d)  Provision of personal protective clothing such as safety shoes/booths, 
head helmets, hand gloves, eye goggles etc. for work on site. 
(e)  -born operations 
(f) 
appropriate and approval vehicle driven by statutory licensed drivers. 
(g)  We give encouragement of workers to report all accidents. 
 
 
- 
i. 
takes minutes of such meetings.  
ii. He shall investigate potential hazard at the work place whether or not 
they are drawn to his attention and also examine the causes of accidents 
at the site 
iii.  
their health, safety and welfare at work 
iv. He shall report to the management of the company all such complaints 
 
v. He shall conduct inspection on all equipment, and to see that they are in 
good and safe working conditions.


## Page 292

shall enforce all safety law in existence including the 
following:- 
(i) The factory decree No. 16 of 1987 
(ii)  Mineral oil (safety) regulation of 1963 and to buttress the laws, the 
company’s safety regulations are:- 
(a)   
(b)  Drugs can only be taken if dispensed by competent persons. 
(c)  There shall no be horseplay during working hours. 
(d)  Proper safety, personal protective equipment must be used for work as 
may be required  
(e)  Workers are to report all accidents, incidents and near misses  
(f) Workers must attend all safety meetings.  
 
 
 
“Health is wealth” 
 
activities. 
 
 
statement of Health. 
 
 
 
It is the uttermost aim of this company to ensure the good health of its labour 
force, and to provide a health working environment. 
 
In this regard we  ensure that, all operations associated with various project 
undertaken are executed in such a way that the health of its employees are 
safeguarded. And will comply with all necessary health and sanitary law in 
existence.


## Page 293

The company Health policy guidelines are as follows: 
i.  
ii. 
the company. 
iii.  Encouragement of workers to report any illness  
iv.  
v. All workers shall be educated on the Hygiene and sanitary rules of our 
various clients. 
 
 
 
 
 
 
 
 
 
 
  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
  
 
   
If your   you are sure of the 
underlisted value added services 
ü  
ü Improved scheduling and Very
ü Environmental compliance. 
Our technical team nationwide have an impressive record for 
“
  A
“.


## Page 294

PROJECTS 
EXECUTED


## Page 295

PREVIOUS PROJECTS


## Page 296

S/N    
1 
  
2 Estate Development, Rehabilitation 
and Refurbishing of Motels.
  
3 Construction of University 
Indians.  
  
 
4 Construction of Roads and Bridges   
5 Construction of Roads    
 
 
  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
  
 
 
 
 
 6Federal Ministry ofWorks, Nigeria.Port-Harcourt NigeriaThe Emergency Repair of Burnt 
and Damaged Issac Boro Flyover 
Bridge, Rivers State.Federal Ministry of
Works, Nigeria. Jamaica.Romania Israel.
7Federal Ministry of
Works, Lagos Nigeria.The Emergency Repairs/
Replacement of Bridge Expansion 
Joints at Ijora 7th Up Bridge in 
Lagos State
8Federal Ministry of
Works, Lagos Nigeria.The Repairs of Dormanlong Bridge
in Lagos State.
9Federal Ministry of
Works, Kogi Nigeria.The Rehabilitation of Murtala 
Mohammed Bridge, Koton-Karfe 
in Kogi State.
10NEWMAP/WORLD BANK 
PROJECT: Stabiliza on of 
Raﬁngora Gully, 
Emergency Site in 
Niger State.Stabilization of Raﬁngora Gully, 
Emergency Site in Niger State.


## Page 297

S/N    
11  
  
12  
  
13    
 
 Federal Ministry of
Works, Nigeria.
Federal Ministry of
Works, Nigeria.Federal Ministry of
Works, Nigeria.
Rehabilitation of Ikare - Arigidi - 
Ajowa Road, Ondo State.Rehabilitation of Ado - Igede - 
Aramoko - Itawure - Esa Oke 
Junction Ekiti State.Emergency Repair of Regachikum 
Bridge and Dumbi Bridge along 
Abuja - Kaduna - Kano Road, 
Kaduna State.
14 RAAMP World Bank
Projects Contract for Construction/
Upgrading of 14.2km Ile-Oluji
Lota Road-Oboto,Ileoluji / Okeigbo 
L.G.A. Ondo State.


## Page 315

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 316

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 317

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 318

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 319

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 320

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 321

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 322

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 323

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 324

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 325

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 326

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 327

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 328

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 329

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 330

Hallekem Limited, Regachikum Bridge and Dumbi Bridge, 
Kaduna State, Before, After and During the works.


## Page 333

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
The Site Before Hallekem Limited Started the Work


## Page 334

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
The Site Before Hallekem Limited Started the Work


## Page 335

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site Aer Work Done


## Page 336

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site Aer Work Done


## Page 337

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 338

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 339

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 340

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 341

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 342

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 343

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 344

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 345

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 346

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 347

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 348

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 349

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 350

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 351

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 352

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 353

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 354

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 355

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 356

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 357

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 358

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 359

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 360

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 361

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 362

Ministry Of Environment, Newmap, World Bank Project.
Stabilization Of Raﬁngora Emergency Gully Erosion Site In Niger State.
Hallekem Limited Site During the Work


## Page 363

Hallekem Limited, koton-Karfe Bridge, Kogi State. 
Old damaged Expansion Joints Koton-Karfe Bridge


## Page 364

Hallekem Limited, koton-Karfe Bridge, Kogi State. 
Preparing Before Installation of the New Expansion Joints 
(New Deck - End - Beams) and Installation of the New Expansion Joints.


## Page 365

Hallekem Limited, koton-Karfe Bridge, Kogi State. 
Preparing Before Installation of the New Expansion Joints 
(New Deck - End - Beams) and Installation of the New Expansion Joints.


## Page 366

Hallekem Limited, koton-Karfe Bridge, Kogi State. 
Preparing Before Installation of the New Expansion Joints 
(New Deck - End - Beams) and Installation of the New Expansion Joints.


## Page 367

Hallekem Limited, koton-Karfe Bridge, Kogi State. 
Preparing Before Installation of the New Expansion Joints 
(New Deck - End - Beams) and Installation of the New Expansion Joints.


## Page 368

Hallekem Limited, koton-Karfe Bridge, Kogi State. 
Preparing Before Installation of the New Expansion Joints 
(New Deck - End - Beams) and Installation of the New Expansion Joints.


## Page 369

The Rehabilitation of Murtala Mohammed Bridge, Koton-Karfe, Kogi State
Hallekem Limited, Underwater team at Work 2020/2021


## Page 370

The Rehabilitation of Murtala Mohammed Bridge, Koton-Karfe, Kogi State
Hallekem Limited, Underwater team at Work 2020/2021


## Page 371

The Rehabilitation of Murtala Mohammed Bridge, Koton-Karfe, Kogi State
Hallekem Limited, Underwater team at Work 2020/2021


## Page 372

The Rehabilitation of Murtala Mohammed Bridge, Koton-Karfe, Kogi State
Hallekem Limited, Underwater team at Work 2020/2021


## Page 373

The Rehabilitation of Murtala Mohammed Bridge, Koton-Karfe, Kogi State
Hallekem Limited, Underwater team at Work 2020/2021


## Page 374

The Rehabilitation of Murtala Mohammed Bridge, Koton-Karfe, Kogi State
Hallekem Limited, Underwater team at Work 2020/2021


## Page 375

The Rehabilitation of Murtala Mohammed Bridge, Koton-Karfe, Kogi State
Hallekem Limited, Underwater team at Work 2020/2021


## Page 376

The Rehabilitation of Murtala Mohammed Bridge, Koton-Karfe, Kogi State
Hallekem Limited, Underwater team at Work 2020/2021


## Page 377

The Rehabilitation of Murtala Mohammed Bridge, Koton-Karfe, Kogi State  
Hallekem Limited, Starting activities on top of the Bridge, 2020/2021


## Page 378

The Rehabilitation of Murtala Mohammed Bridge, Koton-Karfe, Kogi State  
Hallekem Limited, Starting activities on top of the Bridge, 2020/2021


## Page 379

Dormanlong Bridge, Lagos 
Site Handover & Carriageway Bad Condition  
Hallekem Limited 24th June, 2019


## Page 380

Dormanlong Bridge, Lagos 
Site Handover & Carriageway Bad Condition  
Hallekem Limited 24th June, 2019


## Page 381

Dormanlong Bridge, Lagos 
Scariﬁcation Works on Carriageway 
Hallekem Limited July 2019


## Page 382

Dormanlong Bridge, Lagos 
Scariﬁcation Works on Carriageway 
Hallekem Limited July 2019


## Page 383

Dormanlong Bridge, Lagos 
New Galvanized Guardrails Works 
Hallekem Limited August 2019


## Page 384

Dormanlong Bridge, Lagos 
New Galvanized Guardrails Works 
Hallekem Limited August 2019


## Page 385

Dormanlong Bridge, Lagos 
New Galvanized Guardrails Works 
Hallekem Limited August 2019 
Dormanlong Bridge, Lagos 
Site Inspection by FMW H.Q. 
Hallekem Limited 30th August, 2019


## Page 386

Dormanlong Bridge, Lagos 
New Asphalt Works 
Hallekem Limited 28th July & 18th August, 2019


## Page 387

Dormanlong Bridge, Lagos 
New Asphalt Works 
Hallekem Limited 28th July & 18th August, 2019


## Page 388

Dormanlong Bridge, Lagos 
New Asphalt Works 
Hallekem Limited 28th July & 18th August, 2019


## Page 389

Dormanlong Bridge, Lagos 
New Asphalt Works 
Hallekem Limited 28th July & 18th August, 2019


## Page 390

Dormanlong Bridge, Lagos 
New Asphalt Works 
Hallekem Limited 28th July & 18th August, 2019


## Page 391

Dormanlong Bridge, Lagos 
New Expansion Joints Works 
Hallekem Limited August, 2019


## Page 392

Ijora 7up Bridge, Lagos 
Hallekem Limited 07/12/2018 commissioning the Bridge with the media


## Page 394

Ijora 7up Bridge, Lagos 
Hallekem Limited 07/12/2018 commissioning the Bridge with the media


## Page 395

Ijora 7up Bridge, Lagos 
Hallekem Limited 07/11/2018 Asphalt two layers (modiﬁed asphalt with "Sasobit").


## Page 396

Ijora 7up Bridge, Lagos 
Hallekem Limited 07/11/2018 Asphalt two layers (modiﬁed asphalt with "Sasobit").


## Page 397

Ijora 7up Bridge, Lagos 
Hallekem Limited 07/11/2018 Asphalt two layers (modiﬁed asphalt with "Sasobit").


## Page 398

Ijora 7up Bridge, Lagos 
Hallekem Limited 07/11/2018 Asphalt two layers (modiﬁed asphalt with "Sasobit").


## Page 399

Ijora 7up Bridge, Lagos 
Hallekem Limited 07/11/2018 Asphalt two layers (modiﬁed asphalt with "Sasobit").


## Page 400

Ijora 7up Bridge,Lagos. Site Visit by the FMW H.Q. & Controller 27th July 2018


## Page 401

Ijora 7up Bridge,Lagos. Site Visit by the FMW Controller 24th July 2018


## Page 410

`                                                                                                                              
 
 
 
 
  
 
 
 
 
 
 
 
 
 
 
 
 
IN POLISH, PHASE 1.


## Page 411

CONSTRUCTION OF 5 STAR HOTEL 
“GRAND LIDO HOTEL” JAMAICA.


## Page 415

3 
.


## Page 419

ROAD AND BRIDGE CONSTRUCTION WORK. 
 
 
 
 
 
 
D


## Page 420

D


## Page 421

.


## Page 424

ENGR. HAIM HALLE


## Page 425

D


## Page 428

CONCLUSION


## Page 429

CONCLUSION  
 
The result of good thinking and labour is the resounding success, which lies in 
the choice of our personnel. Ours is a team of talented, dedicated, self-
motivated, hard drive masters, and time-tested expertise. 
 
We believe in excellence and do not compromise standard which is why our 
name stands very conspicuously among the multitudes of experts, and people 
who have same principle and life style always go for us anywhere, anytime. For 
e. 
 
 
Yours faithfully,